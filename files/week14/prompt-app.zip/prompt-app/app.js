const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public')); // Serve static files (e.g., HTML, CSS)

// Routes
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.post('/send_prompt', (req, res) => {
    const prompt = req.body.prompt;
    // Example: sending prompt via HTTP to ESP32S3
    // Implement your sending logic here
    console.log('Received prompt:', prompt);
    res.send('Prompt sent to ESP32S3');
});

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});